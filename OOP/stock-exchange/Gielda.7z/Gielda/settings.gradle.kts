rootProject.name = "Gielda"

