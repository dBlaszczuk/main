package org.example;

// Enumerator typów zleceń
public enum TypZlecenia {
    NATYCHMIASTOWE,
    BEZTERMINOWE,
    WYKONAJ_LUB_ANULUJ,
    WAZNE_DO_KONCA_TURY
}
